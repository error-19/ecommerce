-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2023 at 06:52 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eco`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `user_id`, `created_at`, `updated_at`) VALUES
(29, 1, 4, '2023-01-15 12:26:28', '2023-01-15 12:26:28'),
(30, 25, 4, '2023-01-15 12:50:23', '2023-01-15 12:50:23'),
(31, 26, 4, '2023-01-15 12:52:37', '2023-01-15 12:52:37'),
(32, 3, 4, '2023-01-15 13:15:31', '2023-01-15 13:15:31'),
(40, 33, 17, '2023-02-01 02:09:39', '2023-02-01 02:09:39'),
(66, 1, 20, '2023-02-11 03:16:39', '2023-02-11 03:16:39'),
(67, 6, 20, '2023-02-11 03:16:44', '2023-02-11 03:16:44'),
(68, 7, 20, '2023-02-11 03:16:48', '2023-02-11 03:16:48'),
(78, 6, 3, '2023-02-13 00:08:31', '2023-02-13 00:08:31');

-- --------------------------------------------------------

--
-- Table structure for table `cloths`
--

CREATE TABLE `cloths` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cloths`
--

INSERT INTO `cloths` (`id`, `name`, `price`, `category`, `description`, `gallery`, `created_at`, `updated_at`) VALUES
(1, 'T-shirt', '5', 'T-shirt', 'This is polo t-shirt.This is hundred percent cotton', 'https://static-01.daraz.com.bd/p/75c11be5ae73b15fe01fcfa8ddd4e65e.jpg', NULL, NULL),
(2, 'Shirt', '10', 'shirt', 'This is very nice shirt.', 'https://m.media-amazon.com/images/I/71SBg2P0W4L._AC_UL1500_.jpg', NULL, NULL),
(3, 'Pants', '15', 'pants', 'This pants is very beautiful', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-nGz3gEZ4Ay98dRvmaGipu_mlOfi-OTwnMQ&usqp=CAU ', NULL, NULL),
(4, 'Polo-shirt', '7', 'T-shirt', 'This is hundred percent cotton', 'https://www.shutterstock.com/image-vector/california-ocean-side-stylish-tshirt-600w-1180194466.jpg', NULL, NULL),
(5, 'Easy-Shirt', '8', 'shirt', 'This is very nice t-shirt.', 'https://www.shutterstock.com/image-vector/sunset-blvd-california-tshirt-apparel-600w-1133344727.jpg', NULL, NULL),
(13, 'suit1', '30', 'suit', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material. ', 'https://static-01.daraz.com.bd/p/962be10da1c9678947cce70f6e9c99d3.jpg', NULL, NULL),
(14, 'suits2', '22', 'suits', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/482736ac109fb29137e112fde1d618ee.jpg', NULL, NULL),
(15, 'shirt1', '22', 'shirt', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/c09ea00a28544f3b4fe1c5d97701cc83.png', NULL, NULL),
(16, 'shirt2', '22', 'shirt', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/5a32d0e51410811735ea81c26eaed848.jpg', NULL, NULL),
(17, 'suit3', '35', 'suits', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material.', 'https://static-01.daraz.com.bd/p/5f0eb30ce558f38b7a977eae37dd68ad.jpg ', NULL, NULL),
(18, 'pant1', '30', 'pant', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material. ', 'https://static-01.daraz.com.bd/p/dc068e4614d7289f6df0fc6b3d919795.jpg', NULL, NULL),
(19, 'pant2', '22', 'pant', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/5fe625a31da88a1638761d07089c819a.jpg', NULL, NULL),
(20, 'pant3', '22', 'pant', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/7f17541c8ecacc16379af6bab132140f.jpg', NULL, NULL),
(21, 'shirt5', '22', 'shirt', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/c3b9c793b4fdbcf8676d514756160048.jpg', NULL, NULL),
(22, 'shirt6', '35', 'suits', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material.', 'https://static-01.daraz.com.bd/p/ac33b23a26d3daeee6873f03d74eaafa.jpg', NULL, NULL),
(23, 'suits5', '30', 'pant', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material. ', 'https://static-01.daraz.com.bd/p/e2f94ed817f788e1c31e404444163b65.jpg', NULL, NULL),
(24, 'pant8', '22', 'pant', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/bbd28798eb48ec903bb128783f789fa6.jpg', NULL, NULL),
(25, 'shirt7', '22', 'pant', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/2e4a4dca3a5f352489a99d4edfeca633.jpg', NULL, NULL),
(26, 'suit', '22', 'shirt', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/99e1e730956445d9369edcad0964baa3.jpg', NULL, NULL),
(27, 'shirt6', '35', 'suits', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material.', 'https://static-01.daraz.com.bd/p/b7b8df56e3a16b813085e969d1c50822.jpg', NULL, NULL),
(28, 'suits6', '30', 'pant', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material. ', 'https://static-01.daraz.com.bd/p/266895f41f3d913316a5a3f3edf5806d.jpg', NULL, NULL),
(29, 'pant9', '22', 'pant', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/35234231cef9944a7c2da77af61dabc2.jpg', NULL, NULL),
(30, 'shirt8', '22', 'pant', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/b9612b46bb35792a7c2d700f1778b706.jpg', NULL, NULL),
(31, 'suit7', '22', 'shirt', '\n                This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/380006723919737256f2eee1c7b8b78d.jpg', NULL, NULL),
(32, 'suits8', '30', 'pant', 'Tailored Fit Two Piece Suit\n            ৳6,563.20৳9,376.00\n            This Two button suit comes in blended material. ', 'https://static-01.daraz.com.bd/p/7e707b5ba03009d2442f51a9f25681b3.jpg', NULL, NULL),
(33, 'pant10', '22', 'pant', '\n            This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/88657ad7dd7e655775a54f3b009eeb9f.jpg', NULL, NULL),
(34, 'shirt9', '22', 'pant', '\n            This Two button suit comes in blended material. Featuring a clean, understated style, it\'s also an ideal go-to option to showcase at special occasions.', 'https://static-01.daraz.com.bd/p/e0be210ffff848bfc5f49af42f47893e.jpg', NULL, NULL),
(35, 'shirt10', '35', 'suits', 'Tailored Fit Two Piece Suit\n                ৳6,563.20৳9,376.00\n                This Two button suit comes in blended material.', 'https://static-01.daraz.com.bd/p/e0be210ffff848bfc5f49af42f47893e.jpg', NULL, NULL),
(36, 'dfgfdg', '5', 'dfgdfgdf', 'dfgdfgdfg', 'dfgdfg', '2023-02-11 23:56:15', '2023-02-11 23:56:15'),
(37, 'Saree4', '13', 'saree', 'This is very Nice Saree.', 'https://static-01.daraz.com.bd/p/f3d1eedc29cbc8f0884d290011e0016a.jpg', '2023-02-11 23:58:58', '2023-02-11 23:58:58'),
(38, 'Perfium', '4', 'perfium', 'This is very good perfium', 'https://static-01.daraz.com.bd/p/3bacbff476cd025c684ead14d169e9c4.jpg', '2023-02-12 00:00:01', '2023-02-12 00:00:01'),
(39, 'perfium', '6', 'perfium', 'This is very Useful perfium', 'https://static-01.daraz.com.bd/p/3bacbff476cd025c684ead14d169e9c4.jpg', '2023-02-12 00:00:39', '2023-02-12 00:00:39'),
(40, 'dfhftg', '8', 'fghfgh', 'fghfgh', 'fghfgh', '2023-02-12 00:08:03', '2023-02-12 00:08:03'),
(41, 'erwe', '5', 'dfggfdg', 'dfgf', 'fdgdf', '2023-02-13 08:20:03', '2023-02-13 08:20:03');

-- --------------------------------------------------------

--
-- Table structure for table `electrics`
--

CREATE TABLE `electrics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `electrics`
--

INSERT INTO `electrics` (`id`, `name`, `price`, `category`, `description`, `gallery`, `created_at`, `updated_at`) VALUES
(1, 'Oppo mobile', '300', 'mobile', 'A smartphone with 8gb ram and much more feature', 'https://assetscdn1.paytm.com/images/catalog/product/M/MO/MOBOPPO-A52-6-GFUTU6297453D3D253C/1592019058170_0..png', NULL, NULL),
(6, 'Electric Hair clipper', '8', 'clipper', 'This is very Nice Clipper', 'https://static-01.daraz.com.bd/p/8961bb8e53d5bc7d4e5e2dd8bbc958b7.jpg', '2023-02-13 00:59:05', '2023-02-13 00:59:05'),
(7, 'vision Pan', '6', 'pan', 'This is very good pan', 'https://static-01.daraz.com.bd/p/ccbec301d1f88cf6949410b6e77ba7b4.jpg', '2023-02-13 01:00:28', '2023-02-13 01:00:28'),
(8, 'Digital Mini Termometer', '5', 'Termometer', 'This is very good Thermometer', 'https://static-01.daraz.com.bd/p/3f476ad006bc6531b7ec03a907760d4d.jpg', '2023-02-13 01:01:33', '2023-02-13 01:01:33'),
(9, 'Multiplag', '4', 'multiplug', 'This is very good multiplug', 'https://static-01.daraz.com.bd/p/8400d610f26f879ad685010aed1f07af.jpg', '2023-02-13 01:03:04', '2023-02-13 01:03:04');

-- --------------------------------------------------------

--
-- Table structure for table `healths`
--

CREATE TABLE `healths` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `healths`
--

INSERT INTO `healths` (`id`, `name`, `price`, `category`, `description`, `gallery`, `created_at`, `updated_at`) VALUES
(1, 'Detol Soap', '30', 'Soap', 'This is very Nice Soap.It prevents Virus and Bacteria', 'https://static-01.daraz.com.bd/p/1dcaf2b404abad3da69aa7faf41d3ad8.jpg', NULL, NULL),
(2, 'Detol Body wash', '12', 'Body wash', 'This very Beautiful body wash', 'https://static-01.daraz.com.bd/p/39f86b085acacaf45d2f8e0d2d92fabf.jpg', NULL, NULL),
(3, 'Black Soap', '32', 'soap', 'This soap is unique Flavour', 'https://static-01.daraz.com.bd/p/0adff449585ef7dd044e6d2eb7817acf.jpg', NULL, NULL),
(4, 'Acne-star', '18', 'Acne', 'This is reduce Acne', 'https://static-01.daraz.com.bd/p/5f6adf97e13bcec30b7625eac41ba478.jpg', NULL, NULL),
(5, 'fghfg', '7', 'jhgjgj', 'ghjghj', 'ghjghj', '2023-02-11 23:49:26', '2023-02-11 23:49:26'),
(6, 'dfghdfg', '4', 'bdfgdfg', 'dfgdfgdf', 'dfgfd', '2023-02-12 00:01:48', '2023-02-12 00:01:48'),
(7, 'Hair clipper', '7', 'clipper', 'This is very beautiful Hair clipper', 'https://static-01.daraz.com.bd/p/e11520cced16179d12263f775b318de5.jpg', '2023-02-12 00:07:02', '2023-02-12 00:07:02'),
(8, 'sdfds', '56', 'fgjhhj', 'gjgh', 'ghjgh', '2023-02-12 00:07:39', '2023-02-12 00:07:39'),
(9, 'ghghj', '9', 'hgjgjhgj', 'ghjghj', 'hgjghj', '2023-02-12 00:08:17', '2023-02-12 00:08:17'),
(10, 'dfgdf', '0', 'hgfjh', 'fghfgh', 'fghfgh', '2023-02-12 00:09:48', '2023-02-12 00:09:48');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2023_01_10_124212_create_user_table', 1),
(3, '2023_01_10_142443_create_sessions_table', 1),
(4, '2023_01_11_225156_create_product_table', 2),
(5, '2023_01_11_232841_create_products_table', 3),
(6, '2023_01_12_071542_create_cart_table', 4),
(7, '2023_01_12_110206_create_orders_table', 5),
(8, '2023_02_01_151806_create_product_table', 6),
(9, '2023_02_01_152925_create_products_table', 7),
(10, '2023_02_01_153152_create_products_table', 8),
(11, '2023_02_10_105728_create_electrics_table', 9),
(12, '2023_02_10_112519_create_cloths_table', 10),
(13, '2023_02_11_034946_create_health_table', 11),
(14, '2023_02_11_043726_create_healths_table', 12),
(15, '2023_02_11_045609_create_healths_table', 13),
(16, '2023_02_13_064848_create_electrics_table', 14);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `product_id`, `user_id`, `status`, `payment_method`, `payment_status`, `address`, `created_at`, `updated_at`) VALUES
(1, 4, 2, 'pending', 'cash', 'pending', 'Dhaka', NULL, NULL),
(2, 3, 2, 'pending', 'cash', 'pending', 'Dhaka', NULL, NULL),
(3, 4, 2, 'pending', 'cash', 'pending', 'Dhaka', NULL, NULL),
(18, 3, 1, 'pending', 'cash', 'pending', 'tangial', NULL, NULL),
(19, 4, 7, 'pending', 'cash', 'pending', 'Tangial', NULL, NULL),
(20, 1, 7, 'pending', 'cash', 'pending', 'Tangial', NULL, NULL),
(21, 2, 4, 'pending', 'cash', 'pending', 'kollol', NULL, NULL),
(22, 18, 9, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(23, 34, 9, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(24, 3, 12, 'pending', 'cash', 'pending', 'tangail', NULL, NULL),
(25, 26, 12, 'pending', 'cash', 'pending', 'tangail', NULL, NULL),
(26, 12, 20, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(27, 5, 20, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(28, 7, 20, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(29, 1, 20, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(30, 7, 20, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(31, 16, 20, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(32, 5, 3, 'pending', 'cash', 'pending', 'mmm', NULL, NULL),
(33, 5, 3, 'pending', 'cash', 'pending', 'hhhhgggggggv', NULL, NULL),
(34, 11, 3, 'pending', 'cash', 'pending', 'hhhhgggggggv', NULL, NULL),
(35, 17, 3, 'pending', 'cash', 'pending', 'hhhhgggggggv', NULL, NULL),
(36, 6, 3, 'pending', 'cash', 'pending', 'tangail', NULL, NULL),
(37, 16, 3, 'pending', 'cash', 'pending', 'mmn', NULL, NULL),
(38, 6, 24, 'pending', 'cash', 'pending', 'tangail', NULL, NULL),
(39, 6, 24, 'pending', 'cash', 'pending', 'tangail', NULL, NULL),
(40, 7, 25, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(41, 6, 25, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(42, 5, 25, 'pending', 'cash', 'pending', 'Tangail', NULL, NULL),
(43, 6, 25, 'pending', 'cash', 'pending', 'Mymensign', NULL, NULL),
(44, 6, 25, 'pending', 'cash', 'pending', 'hnjhgjhg', NULL, NULL),
(45, 5, 25, 'pending', 'cash', 'pending', 'Dhaka', NULL, NULL),
(46, 7, 25, 'pending', 'cash', 'pending', 'Dhaka', NULL, NULL),
(47, 17, 25, 'pending', 'cash', 'pending', 'Dhaka', NULL, NULL),
(48, 5, 27, 'pending', 'cash', 'pending', 'rfsdf', NULL, NULL),
(49, 6, 27, 'pending', 'cash', 'pending', 'rfsdf', NULL, NULL),
(50, 5, 27, 'pending', 'cash', 'pending', 'rfsdf', NULL, NULL),
(51, 7, 27, 'pending', 'cash', 'pending', 'rfsdf', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `category`, `description`, `gallery`, `created_at`, `updated_at`) VALUES
(1, 'Oppo mobile', '300', 'mobile', 'A smartphone with 8gb ram and much more feature', 'https://assetscdn1.paytm.com/images/catalog/product/M/MO/MOBOPPO-A52-6-GFUTU6297453D3D253C/1592019058170_0..png', NULL, NULL),
(5, 'Black&WhiteShirt', '20', 'shirt', 'This is very Nice shirt.This is fully coton', 'https://static-01.daraz.com.bd/p/5a32d0e51410811735ea81c26eaed848.jpg', NULL, NULL),
(6, 'Soni Tv', '500', 'tv', 'A tv with much more feature', 'https://static-01.daraz.com.bd/p/9aba4534ce63660ff56a9378381b4ec7.jpg', NULL, NULL),
(7, 'LG fridge', '200', 'fridge', 'A fridge with much more feature', 'https://static-01.daraz.com.bd/p/061aac0579c515a991461a069b8cb51a.jpg', NULL, NULL),
(8, 'Black shirt', '20', 'shirt', 'This is very Nice shirt.This is fully coton', 'https://static-01.daraz.com.bd/p/9e7322027a396e1c7d30822eced05f7c.jpg', NULL, NULL),
(9, 'Vision Tv', '500', 'tv', 'A tv with much more feature', 'https://static-01.daraz.com.bd/p/3326bed9198b5b5b02b14e106da42efa.jpg', NULL, NULL),
(10, 'Black-Saree', '500', 'tv', 'A tv with much more feature', 'https://static-01.daraz.com.bd/p/147149304248f61e06595a33b85d8b15.jpg', NULL, NULL),
(11, 'Walton fridge', '200', 'fridge', 'A fridge with much more feature', 'https://static-01.daraz.com.bd/p/e6949495a2edb7e61797e0d3f8e67c8a.jpg', NULL, NULL),
(12, 'New shirt', '20', 'shirt', 'This is very Nice shirt.This is fully coton', 'https://static-01.daraz.com.bd/p/05dd36b1733264dd81bd96930dbb2ae7.jpg', NULL, NULL),
(13, 'MyOne Tv', '500', 'tv', 'A tv with much more feature', 'https://bd-live-21.slatic.net/kf/S9636d00c36144b568f3ad7a20fe118e96.jpg', NULL, NULL),
(14, 'Blackwhite-Saree', '50', 'tv', 'This is very Beautiful Saree', 'https://static-01.daraz.com.bd/p/955ba738d1013b6aeeb7193f5e113947.jpg', NULL, NULL),
(15, 'Black-Saree', '55', 'saree', 'This is very Nice Saree', 'https://static-01.daraz.com.bd/p/c577c444d3c3514af1da35c0b1a044ed.jpg', NULL, NULL),
(16, 'Marcel fridge', '200', 'fridge', 'A fridge with much more feature', 'https://static-01.daraz.com.bd/p/903cacff963a99f2550d0f85545c49db.jpg', NULL, NULL),
(17, 'Tangail-Saree', '40', 'tv', 'This is very Beautiful Saree', 'https://static-01.daraz.com.bd/p/2b0a649677414e59d3b8c51f84f5079d.jpg', NULL, NULL),
(18, 'Hp Laptop', '200', 'computer', 'This is very good computer', 'https://static-01.daraz.com.bd/p/a09e5bccb1efee3a619ac6eecc4a8b48.png', '2023-02-11 22:47:00', '2023-02-11 22:47:00'),
(19, 'Acer Laptop', '250', 'Laptop', 'This is very Nice Laptop.', 'https://static-01.daraz.com.bd/p/902d1212b6a687633c873cba63c45bc2.jpg', '2023-02-11 22:53:38', '2023-02-11 22:53:38'),
(20, 'Tangail Saree', '30', 'saree', 'This is very beautiful Saree', 'https://static-01.daraz.com.bd/p/2b0a649677414e59d3b8c51f84f5079d.jpg', '2023-02-11 22:59:45', '2023-02-11 22:59:45'),
(21, 'Dhaka Saree', '20', 'saree', 'This is very Nice Saree.', 'https://static-01.daraz.com.bd/p/b18ff5d1ba002898216c2080a2d3b4c6.jpg', '2023-02-11 23:02:40', '2023-02-11 23:02:40'),
(22, 'Register', '2', 'register', 'This is very Useful register', 'https://static-01.daraz.com.bd/p/6896612aa404e7866e63fa44070014d2.jpg', '2023-02-11 23:13:44', '2023-02-11 23:13:44'),
(23, 'fgdfgfd', '77', 'vnbvvb', 'vbnvbnvb', 'vbnbvnbv', '2023-02-11 23:15:55', '2023-02-11 23:15:55'),
(24, 'jkljk', '9', 'hjkjhk', 'hjkhj', 'hjkhj', '2023-02-12 00:05:19', '2023-02-12 00:05:19'),
(25, 'loson', '8', 'loson', 'This is very beautiful Loson', 'https://static-01.daraz.com.bd/p/ae052f2300f82f75a673b9ceb555f060.jpg', '2023-02-12 00:05:55', '2023-02-12 00:05:55'),
(26, 'bmbnm', '98', 'gjkhjk', 'ghjghj', 'ghjghj', '2023-02-12 00:10:12', '2023-02-12 00:10:12'),
(27, 'Electric Hair Clipper', '16', 'clipper', 'This is very beautiful Clipper', 'https://static-01.daraz.com.bd/p/8961bb8e53d5bc7d4e5e2dd8bbc958b7.jpg', '2023-02-13 00:57:56', '2023-02-13 00:57:56'),
(28, 'vision Electric Fry Pan', '8', 'Pan', 'This is very good pan', 'https://static-01.daraz.com.bd/p/ccbec301d1f88cf6949410b6e77ba7b4.jpg', '2023-02-13 00:59:50', '2023-02-13 00:59:50'),
(29, 'Wall Switch', '9', 'switch', 'This is very good switch', 'https://static-01.daraz.com.bd/p/3825eba5bf9f781ee838254342c13607.jpg', '2023-02-13 01:04:23', '2023-02-13 01:04:23');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'shamim', 'mdshamimsorkar19@gmail.com', '$2y$10$ICPY.8dNWqG0xTk37rBBG.8uTsBteRt6G0/lYmMXbLHsMEmpFa8ZW', NULL, NULL),
(2, 'rizvy', 'rizvyakter19@gmail.com', '$2y$10$465F2mLod2ZbZuzHRR0ADunYTU2i4Qgeo/Zng8.lqyizQdHAe7sgO', NULL, NULL),
(3, 'anamul hoque', 'anamul10@gmail.com', '$2y$10$if4C1m0LCYLjz7/VJFLozeZWbpaXmUjPJfT5aSmxOD1KcAs7lhwr2', '2023-01-12 09:49:57', '2023-01-12 09:49:57'),
(4, 'kollol devnath', 'kollol19@gmail.com', '$2y$10$vbHAmPHhrawF2T2gqaWDpee2q5RBCihhUTQp8BFE1PiUmqZU89aZu', '2023-01-12 09:50:54', '2023-01-12 09:50:54'),
(5, 'ana', 'ana@gmail.com', '$2y$10$Rhd0KRe4echmndMAQtt9hO6PFMQaPXJsM0BpavD1XhsoRIj3K4SSK', '2023-01-12 09:52:44', '2023-01-12 09:52:44'),
(6, 'karim', 'karim@gmail.com', '$2y$10$LILOmVxVXOEYhC73s8ouuOsphhqQJNi9lXzwc4t25qHd8CEjNWtti', '2023-01-12 09:54:53', '2023-01-12 09:54:53'),
(7, 'karim', 'karim19@gmail.com', '$2y$10$/5Mcl1c/3UPZq.TjkmKVKuB9BKVtIDUDMk8bUzVjdoTlgkMGur/vC', '2023-01-12 09:56:20', '2023-01-12 09:56:20'),
(8, 'kollol debnath', 'kollol34@gmail.com', '$2y$10$0vrWcVZ4/vZ7.DC83Onr6us7WlIyaTVGWLrSZ5U4tgx8zAxqCPw22', '2023-01-15 11:52:26', '2023-01-15 11:52:26'),
(9, 'Rahim', 'rahim19@gmail.com', '$2y$10$tzFtRNUoM7sAOjAX3swcseDPJMmZ9XYbHQdy9.BTlwCA1YuLw0VuO', '2023-01-15 22:54:04', '2023-01-15 22:54:04'),
(10, 'kollol', 'kollol1234@gmail.com', '$2y$10$K3bRfV9vLGsGoOL6S9y9peDlcMsz4zGDCPgca5WHRJDMnfSaiHDou', '2023-01-25 01:44:06', '2023-01-25 01:44:06'),
(11, 'ruksana', 'ruksana19@gmail.com', '$2y$10$4k/Tf9BWTcWa.8K5q2DA1e3kWfHz1LzX2yOAyrmkfZjUowPojNsQe', '2023-01-25 01:46:01', '2023-01-25 01:46:01'),
(12, 'nandon', 'nandon19@gmail.com', '$2y$10$vsQ07A3ipeaYyTmOjpoUoeiW4XPgLSILqS8kf6gKAnumhB.W2ybEm', '2023-01-26 04:36:02', '2023-01-26 04:36:02'),
(13, 'abcd', 'abcd1@gmail.com', '$2y$10$lRKavqUzwq0wpSlfK4p1b.5mxxudb846jLVGoCgj/R6E2QCmbCRYS', '2023-01-29 08:55:24', '2023-01-29 08:55:24'),
(15, 'mnnn', 'mnnn@gmail.com', '$2y$10$ZqxFLZ3Vhy22prAcCwwNW.Lwe8aVuOoT0ZiaQLch6MN/2GiqxZOrO', '2023-01-30 00:45:29', '2023-01-30 00:45:29'),
(16, 'abcd', 'abcd@gmail.com', '$2y$10$EoFRxRsedeTIkDHNsVVKFeWn6CQUlIGj00OYtjzm9O9xuY3KcXRN.', '2023-01-30 01:06:42', '2023-01-30 01:06:42'),
(17, 'pro', 'pro@gmail.com', '$2y$10$KFh8.S2BV.4xVHpibf5EweDXPPUX2xIRHwCGxs3jw.WkmzK4RMNWa', '2023-02-01 01:59:53', '2023-02-01 01:59:53'),
(20, 'uuuu', 'u@gmail.com', '$2y$10$xL6IoukbAu6b9imPi4V8.OvG031FaJkvbwbmwn/OeZkU0fEcdaiaS', '2023-02-10 06:45:36', '2023-02-10 06:45:36'),
(21, 'Md.Shamim Sorkar', 'admin@gmail.com', '$2y$10$Jr9tJKo.dvsjoPzvDKPGKOot1IRuu/VirHVuvNkIntbL0Bg5bvcHS', '2023-02-13 04:46:35', '2023-02-13 04:46:35'),
(22, 'pp', 'p@gmail.com', '$2y$10$da1W72wddUbJrO1/3co/Ce9irCHSwxkR./TWIPzd4/LSPTQ8txKTi', '2023-02-13 04:47:13', '2023-02-13 04:47:13'),
(24, 'll', 'l@gmail.com', '$2y$10$Rc3fvqmESRM68qRgl9yHquZjL92EO6k3GE6d0Pcui2jAVKil065t.', '2023-02-13 04:51:47', '2023-02-13 04:51:47'),
(25, 'anamul', 'anamul@gmail.com', '$2y$10$KOoqpnuo0nn0nW37gQN/BejJWnLeoj517qHNKUVsyONyMGfdHQAsK', '2023-02-13 06:25:55', '2023-02-13 06:25:55'),
(26, 'k', 'k@gmail.com', '$2y$10$BH81hCXBpl0FTC7fsDP4sOfPKjyrSBCZU0k72a5m7uvTfmaLjsUJe', '2023-02-13 08:18:34', '2023-02-13 08:18:34'),
(27, 'y', 'y@gmail.com', '$2y$10$tnuo.13ZnNWN/wJsV3agD.0hDK6ZAS1tvMvr6lL6U6ZmWdBlY1MDC', '2023-02-13 20:18:37', '2023-02-13 20:18:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloths`
--
ALTER TABLE `cloths`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `electrics`
--
ALTER TABLE `electrics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `healths`
--
ALTER TABLE `healths`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `cloths`
--
ALTER TABLE `cloths`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `electrics`
--
ALTER TABLE `electrics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `healths`
--
ALTER TABLE `healths`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
